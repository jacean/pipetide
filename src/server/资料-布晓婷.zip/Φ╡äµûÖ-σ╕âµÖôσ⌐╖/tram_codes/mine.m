function [ m ] = mine( y)
%MINE Summary of this function goes here
%   Detailed explanation goes here
    n = {@my};
    x=n(1,2);
    m = x *y;

end

function [c] = my(a,b)
   
   c = a+b;

end